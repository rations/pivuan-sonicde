
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was KF6NotificationsConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
find_dependency(Qt6Gui 6.10.0)
if (TRUE)
    find_dependency(Qt6DBus 6.10.0)
endif()

if (NOT TRUE) 
    find_dependency(KF6Config "6.31.0")

    if ()
        find_dependency(LibSnoreToast)
        find_dependency(Qt6Network 6.10.0)
    endif()

    if (TRUE)
        # FindCanberra only provided by ECM, so temporarily add its find modules
        set(_popped_CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH})
        find_dependency(ECM 6.31.0)
        list(APPEND CMAKE_MODULE_PATH ${ECM_FIND_MODULE_DIR})

        find_dependency(Canberra)

        set(CMAKE_MODULE_PATH ${_popped_CMAKE_MODULE_PATH})
    endif()

endif()

include("${CMAKE_CURRENT_LIST_DIR}/KF6NotificationsTargets.cmake")
