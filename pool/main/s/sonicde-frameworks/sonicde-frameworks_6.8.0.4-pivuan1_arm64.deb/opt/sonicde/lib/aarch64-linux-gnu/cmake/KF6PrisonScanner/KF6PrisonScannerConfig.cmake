
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was KF6PrisonScannerConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

if (_KF6PRISON_BACKWARDCOMPAT_FIND)
    # provide only targets by legacy
    include("${CMAKE_CURRENT_LIST_DIR}/KF6PrisonScannerTargets.cmake")
    return()
endif()

include(CMakeFindDependencyMacro)
find_dependency(Qt6Multimedia 6.10.0)

if (NOT TRUE)
    # matching the version used
    find_dependency(ZXing 2.3.0)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/KF6PrisonScannerTargets.cmake")
