#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6KirigamiLayouts" for configuration "Release"
set_property(TARGET KF6KirigamiLayouts APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiLayouts PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core;Qt6::Quick;Qt6::QuickControls2;KF6::KirigamiPlatform;KF6KirigamiLayoutsPrivate"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiLayouts.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiLayouts.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiLayouts )
list(APPEND _cmake_import_check_files_for_KF6KirigamiLayouts "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiLayouts.so.6.31.0" )

# Import target "KF6KirigamiLayoutsPrivate" for configuration "Release"
set_property(TARGET KF6KirigamiLayoutsPrivate APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiLayoutsPrivate PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core;Qt6::Quick;Qt6::QuickControls2;KF6::KirigamiPlatform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiLayoutsPrivate.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiLayoutsPrivate.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiLayoutsPrivate )
list(APPEND _cmake_import_check_files_for_KF6KirigamiLayoutsPrivate "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiLayoutsPrivate.so.6.31.0" )

# Import target "KF6KirigamiPrimitives" for configuration "Release"
set_property(TARGET KF6KirigamiPrimitives APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiPrimitives PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core;Qt6::Quick;KF6::KirigamiPlatform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiPrimitives.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiPrimitives.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiPrimitives )
list(APPEND _cmake_import_check_files_for_KF6KirigamiPrimitives "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiPrimitives.so.6.31.0" )

# Import target "KF6KirigamiTemplates" for configuration "Release"
set_property(TARGET KF6KirigamiTemplates APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiTemplates PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiTemplates.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiTemplates.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiTemplates )
list(APPEND _cmake_import_check_files_for_KF6KirigamiTemplates "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiTemplates.so.6.31.0" )

# Import target "KF6KirigamiControls" for configuration "Release"
set_property(TARGET KF6KirigamiControls APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiControls PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiControls.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiControls.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiControls )
list(APPEND _cmake_import_check_files_for_KF6KirigamiControls "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiControls.so.6.31.0" )

# Import target "KF6KirigamiDelegates" for configuration "Release"
set_property(TARGET KF6KirigamiDelegates APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiDelegates PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiDelegates.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiDelegates.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiDelegates )
list(APPEND _cmake_import_check_files_for_KF6KirigamiDelegates "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiDelegates.so.6.31.0" )

# Import target "KF6KirigamiDialogs" for configuration "Release"
set_property(TARGET KF6KirigamiDialogs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiDialogs PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core;Qt6::Quick;KF6::KirigamiPlatform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiDialogs.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiDialogs.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiDialogs )
list(APPEND _cmake_import_check_files_for_KF6KirigamiDialogs "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiDialogs.so.6.31.0" )

# Import target "KF6KirigamiPolyfill" for configuration "Release"
set_property(TARGET KF6KirigamiPolyfill APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiPolyfill PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Quick"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiPolyfill.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiPolyfill.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiPolyfill )
list(APPEND _cmake_import_check_files_for_KF6KirigamiPolyfill "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiPolyfill.so.6.31.0" )

# Import target "KF6KirigamiFormsPrivateTemplates" for configuration "Release"
set_property(TARGET KF6KirigamiFormsPrivateTemplates APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiFormsPrivateTemplates PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiFormsPrivateTemplates.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiFormsPrivateTemplates.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiFormsPrivateTemplates )
list(APPEND _cmake_import_check_files_for_KF6KirigamiFormsPrivateTemplates "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiFormsPrivateTemplates.so.6.31.0" )

# Import target "KF6KirigamiFormsPrivateFlat" for configuration "Release"
set_property(TARGET KF6KirigamiFormsPrivateFlat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiFormsPrivateFlat PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiFormsPrivateFlat.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiFormsPrivateFlat.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiFormsPrivateFlat )
list(APPEND _cmake_import_check_files_for_KF6KirigamiFormsPrivateFlat "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiFormsPrivateFlat.so.6.31.0" )

# Import target "KF6KirigamiFormsPrivateCards" for configuration "Release"
set_property(TARGET KF6KirigamiFormsPrivateCards APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiFormsPrivateCards PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Core"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiFormsPrivateCards.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiFormsPrivateCards.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiFormsPrivateCards )
list(APPEND _cmake_import_check_files_for_KF6KirigamiFormsPrivateCards "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiFormsPrivateCards.so.6.31.0" )

# Import target "KF6KirigamiForms" for configuration "Release"
set_property(TARGET KF6KirigamiForms APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiForms PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;KF6KirigamiFormsPrivateTemplates;KF6KirigamiFormsPrivateFlat;KF6KirigamiFormsPrivateCards;Qt6::Quick"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiForms.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiForms.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiForms )
list(APPEND _cmake_import_check_files_for_KF6KirigamiForms "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiForms.so.6.31.0" )

# Import target "KF6KirigamiPrivate" for configuration "Release"
set_property(TARGET KF6KirigamiPrivate APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6KirigamiPrivate PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Qml;Qt6::Gui"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiPrivate.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigamiPrivate.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiPrivate )
list(APPEND _cmake_import_check_files_for_KF6KirigamiPrivate "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiPrivate.so.6.31.0" )

# Import target "KF6Kirigami" for configuration "Release"
set_property(TARGET KF6Kirigami APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6Kirigami PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Concurrent;KF6KirigamiControls;KF6KirigamiDelegates;KF6KirigamiPrimitives;KF6KirigamiDialogs;KF6KirigamiLayouts;KF6KirigamiPrivate;KF6KirigamiTemplates;KF6KirigamiForms;KF6KirigamiFormsPrivateTemplates;KF6KirigamiFormsPrivateFlat;KF6KirigamiFormsPrivateCards"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigami.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKirigami.so.6"
  )

list(APPEND _cmake_import_check_targets KF6Kirigami )
list(APPEND _cmake_import_check_files_for_KF6Kirigami "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigami.so.6.31.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
