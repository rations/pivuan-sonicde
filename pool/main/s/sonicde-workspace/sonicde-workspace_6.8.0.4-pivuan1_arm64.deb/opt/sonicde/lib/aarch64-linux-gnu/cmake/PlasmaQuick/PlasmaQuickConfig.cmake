
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was PlasmaQuickConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Any changes in this ".cmake" file will be overwritten by CMake, the source is the ".cmake.in" file.

# do not use PACKAGE_CMAKE_INSTALL_PREFIX after calls to find_dependency, its content can change!
set(PlasmaQuick_INSTALL_PREFIX "${PACKAGE_PREFIX_DIR}")
set_and_check(PlasmaQuick_INCLUDE_DIR    "${PACKAGE_PREFIX_DIR}/include/PlasmaQuick")

include(CMakeFindDependencyMacro)
find_dependency(Qt6Quick "")
find_dependency(Plasma "")

include("${CMAKE_CURRENT_LIST_DIR}/PlasmaQuickTargets.cmake")

set(PlasmaQuick_LIBRARIES Plasma::PlasmaQuick)

