#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::FileMetaData" for configuration "Release"
set_property(TARGET KF6::FileMetaData APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::FileMetaData PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "KF6::I18n;KF6::CoreAddons"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6FileMetaData.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKF6FileMetaData.so.3"
  )

list(APPEND _cmake_import_check_targets KF6::FileMetaData )
list(APPEND _cmake_import_check_files_for_KF6::FileMetaData "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6FileMetaData.so.6.31.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
