#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::PlasmaQuick" for configuration "Release"
set_property(TARGET Plasma::PlasmaQuick APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Plasma::PlasmaQuick PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Svg;KF6::ConfigGui;KF6::ConfigQml;KF6::I18n;KF6::IconThemes;KF6::CoreAddons;KF6::Package;KF6::KIOCore;KF6::KIOWidgets;KF6::Notifications;KF6::Svg;KF6::GuiAddons;KF6::I18nQml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libPlasmaQuick.so.6.8.0"
  IMPORTED_SONAME_RELEASE "libPlasmaQuick.so.7"
  )

list(APPEND _cmake_import_check_targets Plasma::PlasmaQuick )
list(APPEND _cmake_import_check_files_for_Plasma::PlasmaQuick "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libPlasmaQuick.so.6.8.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
