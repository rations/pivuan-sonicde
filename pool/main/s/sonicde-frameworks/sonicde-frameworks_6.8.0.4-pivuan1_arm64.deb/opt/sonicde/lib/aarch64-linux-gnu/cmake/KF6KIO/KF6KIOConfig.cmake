
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was KF6KIOConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Any changes in this ".cmake" file will be overwritten by CMake, the source is the ".cmake.in" file.

include(CMakeFindDependencyMacro)
find_dependency(KF6CoreAddons "6.31.0")
find_dependency(KF6Config "6.31.0")

if (NOT TRUE)
    find_dependency(KF6I18n "6.31.0")

    if (NOT ANDROID)
        find_dependency(KF6Crash "6.31.0")
    endif()

    if (TRUE)
        find_dependency(LibMount)
    endif()

    find_dependency(Qt6Concurrent "6.10.0")
    find_dependency(Qt6Xml "6.10.0")
endif()

if (NOT OFF)
    find_dependency(KF6WindowSystem "6.31.0")

    if (NOT OFF)
        find_dependency(KF6Bookmarks "6.31.0")
        find_dependency(KF6Completion "6.31.0")
        find_dependency(KF6ItemViews "6.31.0")
        find_dependency(KF6JobWidgets "6.31.0")
        find_dependency(KF6Solid "6.31.0")
        find_dependency(KF6WidgetsAddons "6.31.0")
        find_dependency(KF6Service "6.31.0")

        if (NOT TRUE)
            find_dependency(KF6GuiAddons "6.31.0")
            find_dependency(KF6IconThemes "6.31.0")
            find_dependency(KF6ColorScheme "6.31.0")

            if (1)
                find_dependency(KF6DBusAddons "6.31.0")
            endif()
        endif()
    else() # KIOGUI_ONLY
        if (NOT TRUE)
            find_dependency(KF6Solid "6.31.0")
            find_dependency(KF6Service "6.31.0")
        endif()
    endif()
else() # KIOCORE_ONLY
    if (NOT TRUE)
        find_dependency(KF6Service "6.31.0")
    endif()
endif()

find_dependency(Qt6Network "6.10.0")
if (1)
    find_dependency(Qt6DBus "6.10.0")
endif()

include("${CMAKE_CURRENT_LIST_DIR}/KF6KIOTargets.cmake")
