/*
 *  SPDX-FileCopyrightText: 2026 Marco Martin <mart@kde.org>
 *
 *  SPDX-License-Identifier: LGPL-2.0-or-later
 */

import QtQuick
import QtQuick.Layouts
import org.kde.kirigami.platform as Platform
import org.kde.kirigami.forms as Forms

/*!
  \qmltype Form
  \inqmlmodule org.kde.kirigami.forms

  \brief The base class for Form conforming to the
  Kirigami Human Interface Guidelines.

  This is the base element for forms, used for instance in settings pages.
  We usually have a Page that contains a single Form,
  which in turn contains one or more FormGroup, each formGroup containing one or more FormEntry.

  Example usage:
  \qml
  import QtQuick.Controls as QQC
  import org.kde.kirigami as Kirigami

  Kirigami.Form {
    Kirigami.FormGroup {
        title: "Global Settings"
        Kirigami.FormEntry {
            contentItem: QQC.CheckBox {
                text: "Show Sidebar"
            }
        }
        Kirigami.FormEntry {
            contentItem: QQC.CheckBox {
                text: "Auto Save"
            }
        }
    }
    Kirigami.FormGroup {
        title: "Theme Options"
        Kirigami.FormEntry {
            title: "Colors"
            contentItem: QQC.CheckBox {
                text: "Dark Theme"
            }
        }
        Kirigami.FormSeparator {}
        Kirigami.FormEntry {
            contentItem: QQC.CheckBox {
                text: "High Contrast"
            }
        }
        ...
    }
  }
  \endqml
  \sa FormGroup
  \sa FormEntry
  \since 6.24
*/
Item {
    id: root

    // Implementation detail, don't document
    default property alias entries: layout.data
    Accessible.role: Accessible.Form

    implicitWidth: layout.implicitWidth + Platform.Units.smallSpacing * 2
    implicitHeight: layout.implicitHeight + Platform.Units.smallSpacing * 2

    // Internal, don't document
    property bool __collapsed: false

    onWidthChanged: layout.relayoutLabels()

    ColumnLayout {
        id: layout
        // Label changes must update alignment even when implicit geometry stays the same.
        readonly property real labelWidth: {
            let w = 0;
            for (const entry of children) {
                w = Math.max(w, entry?.__maxTextLabelWidth ?? 0);
            }

            if (root.Forms.FormAlignmentGroup.group) {
                for (const form of root.Forms.FormAlignmentGroup.group.forms) {
                    if (!(form instanceof Form) || !form.visible) {
                        continue;
                    }
                    for (const entry of form.entries) {
                        w = Math.max(w, entry?.__maxTextLabelWidth ?? 0);
                    }
                }
            }
            return w;
        }
        property real twinImplicitWidth: 0
        onLabelWidthChanged: relayoutLabels()
        onImplicitWidthChanged: relayoutLabels()
        function relayoutLabels() {
            for (let entry of children) {
                if ("__assignedWidthForLabels" in entry) {
                    entry.__assignedWidthForLabels = Math.round(labelWidth);
                }
            }

            if (root.Forms.FormAlignmentGroup.group) {
                for (let form of root.Forms.FormAlignmentGroup.group.forms) {
                    if (!(form instanceof Form) || !form.visible) {
                        continue;
                    }
                    twinImplicitWidth = Math.max(twinImplicitWidth, form.children[0]?.implicitWidth);
                }
            }

            root.__collapsed = Math.max(implicitWidth, twinImplicitWidth) > root.width;
        }
        anchors {
            top: parent.top
            topMargin: Platform.Units.largeSpacing
            horizontalCenter: parent.horizontalCenter
        }

        width: root.__collapsed
                ? Math.min(implicitWidth, parent.width, Platform.Units.gridUnit * 30)
                : Math.min(Math.max(implicitWidth, twinImplicitWidth), parent.width)
        spacing: Platform.Units.largeSpacing + Platform.Units.smallSpacing
    }
}
