#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KDSoap::WSDiscoveryClient" for configuration "Release"
set_property(TARGET KDSoap::WSDiscoveryClient APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KDSoap::WSDiscoveryClient PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKDSoapWSDiscoveryClient.so.0.4.0"
  IMPORTED_SONAME_RELEASE "libKDSoapWSDiscoveryClient.so.0"
  )

list(APPEND _cmake_import_check_targets KDSoap::WSDiscoveryClient )
list(APPEND _cmake_import_check_files_for_KDSoap::WSDiscoveryClient "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKDSoapWSDiscoveryClient.so.0.4.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
