
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was KF6PrisonConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
find_dependency(Qt6Gui 6.10.0)

# backward compat for KF6::PrisonScanner target provided by this config
if(ON AND KF6Prison_FIND_VERSION VERSION_LESS 6.31.0)
    set(_KF6PRISON_BACKWARDCOMPAT_FIND TRUE)
    find_dependency(KF6PrisonScanner 6.31.0)
    set(_KF6PRISON_BACKWARDCOMPAT_FIND)
endif()

if (NOT TRUE)
    # add access to internal Find modules
    list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")

    find_dependency(QRencode)
    if(ON)
        find_dependency(Dmtx)
    endif()
    if(ON)
        # matching the version used
        find_dependency(ZXing 2.3.0)
    endif()

    # clean-up CMAKE_MODULE_PATH
    list(REMOVE_ITEM CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")
endif()

include("${CMAKE_CURRENT_LIST_DIR}/KF6PrisonTargets.cmake")
