#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KWinX11::kwin" for configuration "Release"
set_property(TARGET KWinX11::kwin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KWinX11::kwin PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Concurrent;Qt6::Sensors;Qt6::Svg;KF6::ColorScheme;KF6::ConfigGui;KF6::ConfigQml;KF6::Crash;KF6::GlobalAccel;KF6::I18n;KF6::I18nQml;KF6::Package;KF6::Service;KDecoration3::KDecoration;KDecoration3::KDecoration3Private;KF6::Notifications;Plasma::Activities"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libkwin-x11.so.6.8.0"
  IMPORTED_SONAME_RELEASE "libkwin-x11.so.6"
  )

list(APPEND _cmake_import_check_targets KWinX11::kwin )
list(APPEND _cmake_import_check_files_for_KWinX11::kwin "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libkwin-x11.so.6.8.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
