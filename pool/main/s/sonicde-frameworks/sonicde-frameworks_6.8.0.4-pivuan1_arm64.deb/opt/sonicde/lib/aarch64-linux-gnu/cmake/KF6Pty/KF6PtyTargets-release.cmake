#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::Pty" for configuration "Release"
set_property(TARGET KF6::Pty APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::Pty PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "KF6::I18n"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6Pty.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libKF6Pty.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::Pty )
list(APPEND _cmake_import_check_files_for_KF6::Pty "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6Pty.so.6.31.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
