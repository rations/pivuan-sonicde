#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KioArchive" for configuration "Release"
set_property(TARGET KioArchive APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KioArchive PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "KF6::I18n;Qt6::Network"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libkioarchive6.so.6.0.0"
  IMPORTED_SONAME_RELEASE "libkioarchive6.so.6"
  )

list(APPEND _cmake_import_check_targets KioArchive )
list(APPEND _cmake_import_check_files_for_KioArchive "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libkioarchive6.so.6.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
