#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SonicVia::SonicVia" for configuration "Release"
set_property(TARGET SonicVia::SonicVia APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SonicVia::SonicVia PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libSonicVia.so.6.31.0"
  IMPORTED_SONAME_RELEASE "libSonicVia.so.6"
  )

list(APPEND _cmake_import_check_targets SonicVia::SonicVia )
list(APPEND _cmake_import_check_files_for_SonicVia::SonicVia "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libSonicVia.so.6.31.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
