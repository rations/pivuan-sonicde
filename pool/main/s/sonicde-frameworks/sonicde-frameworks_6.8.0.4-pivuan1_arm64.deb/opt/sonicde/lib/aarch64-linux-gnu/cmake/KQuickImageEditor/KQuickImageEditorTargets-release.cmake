#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KQuickImageEditor" for configuration "Release"
set_property(TARGET KQuickImageEditor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KQuickImageEditor PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Concurrent;KF6::ConfigCore;KF6::ConfigGui"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKQuickImageEditor.so.0.7.0"
  IMPORTED_SONAME_RELEASE "libKQuickImageEditor.so.1"
  )

list(APPEND _cmake_import_check_targets KQuickImageEditor )
list(APPEND _cmake_import_check_files_for_KQuickImageEditor "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKQuickImageEditor.so.0.7.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
